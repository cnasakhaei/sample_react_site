import React from "react";
import Item from "./Item";
import { BEWITH } from "./Links";

const BeWith = () => {
  return (
    <div>
      <Item Links={BEWITH} title="همراه باشید" />
    </div>
  );
}
export default BeWith;