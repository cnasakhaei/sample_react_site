export const MAILS = [
    { name: "arezoo.a.t@gmail.com", link: "mailto: arezoo.a.t@gmail.com" },
    { name: "arezoo_at@ymail.com", link: "mailto: arezoo_at@ymail.com" },
];
  export const BEWITH = [
    { name: "سوالات رایج", link: "#" },
    { name: "قوانین", link: "#" },
    { name: "خدمات", link: "#" },
];