const Copyright = () => {
    return (
        <div className="w-screen text-sm bg-[#093d41] h-20 text-center table-cell align-middle text-gray-100">
            کلیه حقوق محصولات و محتوای این سایت متعلق به بامبو می باشد و هرگونه کپی برداری از محتوای سایت غیرمجاز و بدون رضایت ماست
        </div>
    )
};
export default Copyright;